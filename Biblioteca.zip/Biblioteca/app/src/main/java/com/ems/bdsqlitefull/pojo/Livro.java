package com.ems.bdsqlitefull.pojo;

import java.io.Serializable;

// POJO - Plain Old Java Objects
public class Livro implements Serializable {
    private int id;
    private String titulo;
    private String autor;
    private String genero;

    /**
     * Método construtor vazio
     */
    public Livro() {
    }

    /**
     * Método construtor da classe com assinatura
     *
     * @param titulo
     * @param autor
     * @param genero
     */
    public Livro(String titulo, String autor, String genero) {
        this.titulo = titulo;
        this.autor = autor;
        this.genero = genero;
    }

    /**
     * Método construtor da classe com assinatura
     *
     * @param id
     * @param titulo
     * @param autor
     * @param genero
     */
    public Livro(int id, String titulo, String autor, String genero) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.genero = genero;
    }
    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String gettitulo() {
        return titulo;
    }

    public void settitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getautor() {
        return autor;
    }

    public void setautor(String autor) {
        this.autor = autor;
    }

    public String getgenero() {
        return genero;
    }

    public void setgenero(String genero) {
        this.genero = genero;
    }

    /**
     * Método sobrescrito para retornar o titulo do livro na ListView
     *
     * @return
     */
    @Override
    public String toString() {
        return titulo;
    }

    /**
     * Método que retorna todos os dados de uma só vez
     *
     * @return
     */
    public String getDados() {
        return  "ID: " + id + "\n" +
                "TÍTULO: " + titulo + "\n" +
                "AUTOR: " + autor + "\n" +
                "GÊNERO: " + genero;
    }
}