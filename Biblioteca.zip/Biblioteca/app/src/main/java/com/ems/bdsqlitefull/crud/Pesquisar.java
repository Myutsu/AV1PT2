package com.ems.bdsqlitefull.crud;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.ems.bdsqlitefull.R;
import com.ems.bdsqlitefull.pojo.Livro;

import androidx.appcompat.app.AppCompatActivity;

public class Pesquisar  extends AppCompatActivity{

    EditText pesquisar;
    Button btnPesquisar;

    SQLiteDatabase db;

    Livro livro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesquisar);

        pesquisar = findViewById(R.id.pesquisarPt);
        btnPesquisar = findViewById(R.id.pesquisarBtn);


        db = openOrCreateDatabase("db_livro", Context.MODE_PRIVATE, null);


        btnPesquisar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String busca = pesquisar.getText().toString();

                Cursor c = db.rawQuery("SELECT * FROM livro WHERE titulo = ? COLLATE NOCASE", new String[] { busca });
                while (c.moveToNext()) {
                    livro = new Livro(
                            c.getInt(0),
                            c.getString(1),
                            c.getString(2),
                            c.getString(3));
                }
                if(livro != null) {
                    Intent intent = new Intent(getApplicationContext(), DetalharLivro.class);
                    intent.putExtra("objLivro", livro);
                    startActivity(intent);
                }
                else{
                    Context context = getApplicationContext();
                    CharSequence text = "Livro não encontrado.";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }

            }
        });
    }
}



