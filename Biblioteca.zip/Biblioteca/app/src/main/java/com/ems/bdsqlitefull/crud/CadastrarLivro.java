package com.ems.bdsqlitefull.crud;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.ems.bdsqlitefull.pojo.Livro;
import com.ems.bdsqlitefull.R;
import com.ems.bdsqlitefull.utils.Message;

public class CadastrarLivro extends AppCompatActivity {
    EditText titulo, autor, genero;
    Button btCadastrar;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        // Abertura ou criação do Banco de Dados
        db = openOrCreateDatabase("db_livro", Context.MODE_PRIVATE, null);

        // Cria a tabela se não existir, senão carrega a tabela para uso
        db.execSQL("CREATE TABLE IF NOT EXISTS livro(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "titulo VARCHAR NOT NULL, " +
                "autor VARCHAR NOT NULL, " +
                "genero VARCHAR NOT NULL);");

        // Mostra um botão na Barra Superior para voltar
        getSupportActionBar().setTitle("BIBLIOTECA - CADASTRO");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        titulo = findViewById(R.id.edittitulo);
        autor = findViewById(R.id.editautor);
        genero = findViewById(R.id.editgenero);
        btCadastrar = findViewById(R.id.btCadastrar);

        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Cria um objeto Livro para receber os dados
                Livro livro = new Livro();
                livro.settitulo(titulo.getText().toString());
                livro.setautor(autor.getText().toString());
                livro.setgenero(genero.getText().toString());

                // Coleta os dados digitados nos campos
                ContentValues values = new ContentValues();
                values.put("titulo", livro.gettitulo());
                values.put("autor", livro.getautor());
                values.put("genero", livro.getgenero());

                // Insere os dados na tabela
                db.insert("livro", null, values);

                // Cria uma caixa de mensagem e mostra os dados incluídos
                Message message = new Message(CadastrarLivro.this);
                message.show(
                        "Livro cadastrado com sucesso!",
                        livro.getDados(),
                        R.drawable.ic_add);

                // Limpa os campos de entrada
                clearText();
            }
        });
    }

    // Configura o botão (seta) na ActionBar (Barra Superior)
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /**
     * Limpa os campos de entrada e fecha o teclado
     */
    public void clearText() {
        titulo.setText("");
        autor.setText("");
        genero.setText("");

        // fecha o teclado virtual
        ((InputMethodManager) CadastrarLivro.this.getSystemService(
                Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(
                getCurrentFocus().getWindowToken(), 0);
    }
}
