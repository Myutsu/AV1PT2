package com.ems.bdsqlitefull.crud;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.ems.bdsqlitefull.R;
import com.ems.bdsqlitefull.pojo.Livro;

public class DetalharLivro extends AppCompatActivity {
    Button btEditar;
    Button btDeletar;
    TextView id, titulo, autor, genero;

    SQLiteDatabase db;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        // Mostra um botão na Barra Superior para voltar
        getSupportActionBar().setTitle("BIBLIOTECA - DETALHES");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        db = openOrCreateDatabase("db_livro", Context.MODE_PRIVATE, null);

        id = findViewById(R.id.id);
        titulo = findViewById(R.id.titulo);
        autor = findViewById(R.id.autor);
        genero = findViewById(R.id.genero);
        btEditar = findViewById(R.id.btSalvar);
        btDeletar = findViewById(R.id.btExcluir);

        Intent itLivro = getIntent();
        final Livro livro = (Livro) itLivro.getExtras().getSerializable("objLivro");
        id.setText(String.valueOf(livro.getId()));
        titulo.setText(livro.gettitulo());
        autor.setText(livro.getautor());
        genero.setText(livro.getgenero());

        btEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent editar = new Intent(getApplicationContext(), EditarLivro.class);
                editar.putExtra("objLivro", livro);
                startActivity(editar);
            }
        });
        btDeletar = findViewById(R.id.btExcluir);
        btDeletar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                    Context context = getApplicationContext();
                    CharSequence text = "Carro " + livro.toString() + " deletado com sucesso!";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();

                    db.delete("livro", "id=?", new String[]{String.valueOf(livro.getId())});
                    finish();


            }
        });
    }

    // Configura o botão (seta) na ActionBar (Barra Superior)
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}